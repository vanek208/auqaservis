const openPopUp = document.getElementById('open_pop_up');
const closePopUp = document.getElementById('pop_up_close');
const popUp = document.getElementById('pop_up');

openPopUp.addEventListener('click', function (e) {
	e.preventDefault();
	popUp.classList.add('active');
})
closePopUp.addEventListener('click', () => {
	popUp.classList.remove('active');
})

const openPopUp2 = document.getElementById('open_pop');
const closePopUp2 = document.getElementById('pop_up_clos');
const popUp2 = document.getElementById('pop');

openPopUp2.addEventListener('click', function (e) {

	e.preventDefault();
	popUp2.classList.add('active');
})
closePopUp2.addEventListener('click', () => {
	popUp2.classList.remove('active');
})

const openPopUp3 = document.getElementById('open_pop_u');
const closePopUp3 = document.getElementById('pop_up_closi');
const popUp3 = document.getElementById('pope');

openPopUp3.addEventListener('click', function (e) {

	e.preventDefault();
	popUp3.classList.add('active');
})
closePopUp3.addEventListener('click', () => {
	popUp3.classList.remove('active');
})
const openPopUp4 = document.getElementById('sos');
const closePopUp4 = document.getElementById('pop_up_clasi');
const popUp4 = document.getElementById('ppe');

openPopUp4.addEventListener('click', function (e) {

	e.preventDefault();
	popUp4.classList.add('active');
})
closePopUp4.addEventListener('click', () => {
	popUp4.classList.remove('active');
})
const openPopUp5 = document.getElementById('soss');
const closePopUp5 = document.getElementById('pop_up_clasis');
const popUp5 = document.getElementById('ppes');

openPopUp5.addEventListener('click', function (e) {

	e.preventDefault();
	popUp5.classList.add('active');
})
closePopUp5.addEventListener('click', () => {
	popUp5.classList.remove('active');
})

const openPopUp6 = document.getElementById('otkrit');
const closePopUp6 = document.getElementById('zarkit');
const popUp6 = document.getElementById('info');

openPopUp6.addEventListener('click', function (e) {

	e.preventDefault();
	popUp6.classList.add('active');
})
closePopUp6.addEventListener('click', () => {
	popUp6.classList.remove('active');
})

