<?php
		$mysql = new mysqli ('localhost','root','root','site');
		if (!$mysql){
  		  echo "Error include data baze";
		}
		
?>